#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define SIZE 20
#define m 2//As mentioned in the README.txt file, i implement the hash struct with only 2 buckets at start

//typedef
typedef enum { No, Yes } bool;
typedef struct katalogNode katalogNode;
typedef struct listNode listNode;
typedef struct invertedNode invertedNode;
typedef struct Record Record;
typedef struct bucket bucket;
typedef struct globalhead globalhead;
typedef struct globalhead* global;

//function types

void RunApplication(global head, int x);//This function runs the application
void PrintPromt(void);//prints the output message for the prototype of mvote's 9 operations

//for the katalog struct
global Initialize_Input(char* s);//Initializes the records from the file voters5...csv 
//and puts them in a katalog that can be accessed through the global pointer
int EmptyList(katalogNode * p);//Checks if the katalog is empty
void PrintLIst(katalogNode* p);//Prints the katalog of records

//for the list struct
int AddtoList(int x, global p);//Adds a voter(that has already voted) in a list considering their TK's
void PrintinvertedList(global p);//Prints the above list of voters that have already voted
katalogNode* SearchInhash(int x, global head);//This function uses the hashtable to quickly 
                                            //find and return the adress of the given Pin in the katalog struct

//Sorting functions(used in the list struct):
//The functions for implementing the MergeSort algorithm for the list struct
global MergeSort(global p);//This is a classic Sort function to sort the above list. The implementation is
// firtly done from top to bottom by spltting the intiial list into 2 sub-lists, split in the middle node
//(using getmiddle function). After all of  the calls of Mergesort are done the implementation is continued
//bottom to top by merging(depending which TK has a higher value) the sublists before returning. 
invertedNode* getmiddle(invertedNode* head);//Finds the middle Node of the list and returns a pointer to it
invertedNode* merge(invertedNode* left, invertedNode* right);//Merges the two halfs of the given list ( left and right), with edge cases a list with a signle node
invertedNode* MergeSortList(invertedNode* head);//Sorts the list

//All the functions for implementing the hashtable struct
void Initialize_Hashtable(int x, global head);
int hashfunction(int x, int i);
void rehash(global head, int b);
void printHashTable(global head);
//the below functions insert a record to the correct bucket
void AddtoHashTable(int key,katalogNode* current,bucket** bucketpointer, int b);
Record* createNewRecord(katalogNode* current);
bucket* createNewBucket(Record* record);

//Helper functions for the functionality of Runapllication's function
int CheckifInt(char* str);//Checks if one string is representing an integer or not, if Yes returns 0, if not returns 1
int CheckifStringsEqual(char* str1, char* str2);//Checks if two strings are equal, if Yes returns 0, if not returns 1
                                                //the CheckifstringsEqual function was implemented cause the use of string.h is prohibited for this exercise
//Helper functions to free each struct
int freekatalog(global head);//frees the katalog struct
int freeList(global head);//frees the list struct
int freeHashtable(global head);//frees the hashtable struct
