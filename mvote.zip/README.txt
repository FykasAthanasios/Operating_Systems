# Mmvote App, Operation System K22 Project 1
(The program is fully implemented)

-Explaining the Project:
    The project handles a list of voters from a file(exp. voters50.csv). The program is implemented,
so that you can access all the of the program useful structs through a Global pointer head, that points 
into a globalhead struct.
    The program consists of 3 structs(this was mostly used to break down the program into parts, so its 
easier to implement/ explain / debug). All memory has been dynamically allocated, no static allocation has
been used. First its the katalog struct that saves the voters from the input file (exp voters50.csv) into a
linked list. Each voter(katalogNode) is consisted of its Pin|lname|fname|TK and its voted status. For the 
fname/lanme i allocate dynamically a maximum of 20 characters. If theres bigger strings used for fname or
lname you can change it through there. Then those records are being inserted into the hashtablestruct.
This implementation uses a linear hashtable struct so the search function is 0(1). The hashtable struct is
a double linked list of bucket pointers pointing to records(voters). The record struct only hss the Pin of
the voter, but you can access the rest of it's data through a pointer pointing to the correct index in the
katalog struct(This is also implemented later in the inverted list struct). This way every struct is 
connected to each other and i dont have to allocate memory twice for each voter. I also want to mention
that i use #define m which m is the initial number of buckets. In this implementation i used m=2 with only
buckets 0 and 1(referencing the implementation in the https://www.alexdelis.eu/LinearHashing-CD21.pdf ).
Also i used lambda=0.75 as the breakpoint for when a bucket split should occur. Lastly we have the inverted
list struct thats a double linked list. Its elements are the diffrenrt TK' and every one of them points to
a linked list of voters(that have Marked voted).
    For libraries im using the standard C libraries <stdio.h>, <stdlib> but also including the math.h for
the calculation of the Hash function H(i)(k)= k mod 2^i * m(m mentioned before).
    I tried implementing the program mostly using the notes and referencing to Picture 1 in 
https://www.alexdelis.eu/k22/OS-F23-Proj1.pdf .

-How to use:
    The program is compliled by typing make in the terminal through a Makefile and runs with the instruction
./mvote -f filename (exp. voters5000.csv) -b m (exp. 3). Then it Ininitializes all the voters from the 
"filename" and prints a list of the instruction that the program runs. For the implementation of the 
instructions( the https://www.alexdelis.eu/k22/formatted-output.f23-prj1.txt is referenced).

-Complexity of the program: 
The program for average cases of lookup, insertion has complexity O(1)

katalog struct: 
    Insert is O(1): At the start it inserts the voters from the input file within a loop
and then with the instruction i, it inserts the new voter at the start of the list.

hashtable struct:
    Search is O(bxo):
Traversing through buckets and records is O(bxo), where b is the bucket's capacity and o is the number
of overflow buckets.
    Insert is O(n^2xb^2):
Checking if the bucket at the key is NULL is O(1),
Traversing through the linked buckets, the maximum number of overflow buckets is O(n)
Traversing through the records in a bucket, the maximum number of records is b, so O(b)
but in most cases were b is a small constant the complexity of the Insert is O(n).
If rehashing occurs
Reinserting the records using new hash function in case we need to rehash the values is O(nxb)
Although due to the implementation's good sized tables and the complexity of the hash function n and b
are kept to small values so the complexity of the program is still manageable.

inverted list struct:
    Insert is O(m): SearchHash is O(1) , prints and memory allocations are O(1), looping through the inverted
list is O(m) which m is the number of records in buckets, all other operations are O(1).
