#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "interface.h"
#define m 2
#define SIZE 20

int main(int argc,char* argv[]){
    global head=Initialize_Input(argv[2]);
    Initialize_Hashtable(atoi(argv[4]),head);
    RunApplication(head, atoi(argv[4]));
    return 0;
}
