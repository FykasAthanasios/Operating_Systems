#include <stdio.h>
#include <stdlib.h>
#include "interface.h"

//structs

//represents a voter with details like pin, name, postal code (TK),
//vote status, and a pointer to the next voter
struct katalogNode{
    int Pin;
    char* fname;
    char* lname;
    int TK;
    bool vote;
    struct katalogNode* next;
};

// is a node in a list that contains a pointer to a voter and its pin.
struct listNode{
    int Pin;
    katalogNode* data;
    struct listNode* next;
};
//represents a list of voters sorted by their postal codes (TK).
struct invertedNode{
    struct invertedNode* next;
    listNode* N;
    int number;//number counts the number of voters that have already voted with a speciafied TK
    int TK;// which is the key for this structure
};

//for the hash table
//Each bucket has a maximum of b records, so each bucket is a linked list in this representation
struct Record{
    int Pin;
    katalogNode* k;
    struct Record* next;
};

struct bucket{
    Record* Rp;
    int elementsInbucket;//this is used cause from user input we select with the -b flag
    // how many elements are aloud inside a bucket
    struct bucket* next;//for overflow buckets
};

//itss a global structure containing the main list of voters, 
//a list of voters sorted by their postal code, and some counters.
struct globalhead{
    //for the hash table
    bucket** hs;
    float lamda;
    int splitbucket;
    int i;
    int numberofbuckets;
    int bucketsatstart;
    //for the katalog
    struct katalogNode* k;
    // for the list
    struct invertedNode* l;
    int count;//count will be measuring the total amount of records in the database
    int counthasvoted;//counthasvoted counts the number of participants that have voted
};

//The function that runs the applicaion itself, handles 9 different operations for the mvotes database
void RunApplication(global head,int x){
    char perc[]="perc";
    char bv[]="bv";
    char end[]="exit";
    char* instruction=(char*)malloc(20 *sizeof(char));//maximum of 20 characters
        if(instruction==NULL){
            printf("Error, malloc couldnt allocate memory");
            exit(1);
        }
    while(1){
        PrintPromt();
        scanf("%s", instruction);
        if(*instruction=='l'){//Then we are on instruction 1, we just need to do a SearchHashtable
            char* str=(char*)malloc(20*sizeof(char));
            scanf("%s",str);
            if(CheckifInt(str)==1){
                printf("Malformed Pin\n");
                continue;
            }
            int x=atoi(str);
            katalogNode* found;
            found=SearchInhash(x, head);
            if(found==NULL){
                printf("Participant %d not in cohort\n",x);
            }
            else{
                printf("Pin:%d lname:%s fname: %s TK: %d status: ",
                found->Pin,
                found->lname,
                found->fname,
                found->TK);
                if(found->vote==No){
                    printf("No\n");
                }
                else{
                    printf("Yes\n");
                }
            }
            free(str);
            continue;
        }
        if(*instruction=='i'){
            int Pin, TK;
            char* lname=(char*)malloc(20*sizeof(char));
            char* fname=(char*)malloc(20*sizeof(char));
            if(lname==NULL ||  fname==NULL ){
                printf("Error, malloc couldnt allocate memory");
                exit(1);
            }
            if(scanf("%d%s%s%d", &Pin, lname, fname, &TK)!=4){
                printf("Malformed Input\n");
                continue;
            }
            if(CheckifInt(lname)!=1 || CheckifInt(fname)!=1){
                printf("Malformed Input\n");
                continue;
            }
            if(SearchInhash(Pin,head)!=NULL){
                printf("%d already exist\n", Pin);
                continue;
            }
            katalogNode* A=(katalogNode*)malloc(sizeof(katalogNode));
            if(A==NULL){
                printf("Error malloc couldnt allocate memory");
                exit(1);
            }
            A->Pin=Pin;
            A->fname=fname;
            A->lname=lname;
            A->TK=TK;
            A->vote=No;
            //insert it into the katalog struct
            A->next=head->k;
            head->k=A;
            //insert it into the hashtable struct
            int numberofrecordsinbuckets=x;
            int key=hashfunction(Pin,head->i);
            if(key< head->splitbucket){//if h(i)(k) < p
                key=hashfunction(Pin, (head->i)+1);
                AddtoHashTable(key,head->k,head->hs, numberofrecordsinbuckets);
                head->count++;
            }
            else{
                AddtoHashTable(key,head->k,head->hs, numberofrecordsinbuckets);
                head->count++;
            }
            head->lamda=(float) head->count /((float) (head->numberofbuckets) * (float) numberofrecordsinbuckets);
            if(head->lamda > 0.75){
                //bucketsplit == REALLOC by 1 bucket at a time
                head->numberofbuckets++;
                head->hs=(bucket **)realloc(head->hs, (head->numberofbuckets) *sizeof(bucket *));
                head->hs[head->numberofbuckets-1]=NULL;
                //rehash the values of p and OF buckets with h(i+1)(k)
                rehash(head,numberofrecordsinbuckets);
                head->splitbucket++;
            }
            if(head->numberofbuckets==2* head->bucketsatstart){
                head->splitbucket=0;
                head->i++;
                head->bucketsatstart=head->numberofbuckets;
            }
            continue;
        }
        if(*instruction=='m'){
            char* str=(char*)malloc(20*sizeof(char));
            scanf("%s",str);
            if(CheckifInt(str)==1){
                printf("Malformed Pin\n");
                continue;
            }
            int x=atoi(str);
            if(AddtoList(x, head)==0){
                printf("|%d| Marked Voted\n",x);
            }
            free(str);
            continue;
        }
        if((CheckifStringsEqual(bv,instruction))==0){
            char* str=(char*)malloc(30* sizeof(char));//maximum of 30 characters for file name
            scanf("%s", str);
            FILE* fp=fopen(str, "r");
            if(fp==NULL){
                printf("fopen failed to open file");
                exit(1);
            }
            int key;
            while((fscanf(fp,"%d",&key))==1){
                AddtoList(key,head);
            }
            free(str);
            fclose(fp);
            continue;
        }
        if(*instruction=='v'){
            if(head->counthasvoted==0){
                printf("None\n");
            }
            else{
                printf("Voted so far %d\n",head->counthasvoted);
            }
            continue;
        }
        if((CheckifStringsEqual(perc,instruction)==0)){
            float x=100 *((float) head->counthasvoted)/((float) head->count);
            if(x==0){
                printf("None\n");
            }
            else{
                printf("%.2f %%\n",x);
            }
        }
        if(*instruction=='z'){
            int x;
            scanf("%d",&x);
            invertedNode* current=head->l;
            int signal=-1;//if we dont find the TK
            while(current!=NULL){
                if(current->TK==x){//found the TK
                    signal=0;
                    printf("%d | has %d voters ",current->TK,current->number);
                    listNode* temp=current->N;
                    while(temp!=NULL){
                        printf("%d ", temp->Pin);
                        temp=temp->next;
                    }
                    printf("\n");
                }           
                current=current->next;
            }
            if(signal==-1){
                printf("None\n");
            }
        }
        if(*instruction=='o'){
            PrintinvertedList(head);
            printf("\n");
            continue;
        }
        if((CheckifStringsEqual(end,instruction)==0)){//check if instruction==exit
            //free everything
            free(instruction);
            int totalbytes=freeList(head)+freekatalog(head)+freeHashtable(head)+sizeof(head);
            printf("free'ed %d bytes\n", totalbytes);
            free(head);
            exit(0);
        }
    }
}

//Helper functions for the functionality of the Runapplication function
int CheckifStringsEqual(char* str1, char* str2){//This is only used instead of strcmp
//cause the use of string.h is prohibited for this assingment
    while(*str1!='\0' && *str2!='\0'){
        if(*(str1) != *(str2)){//if you find a character thats different
            return 1;//Strings are not equal
        }
        str1++;
        str2++;
    }
    if(*str1!='\0' || *str2!='\0'){//if we havent reached the end on both strings then they are not equal
        return 1;
    }
    printf("%s %s\n",str1, str2 );
    return 0;//strings are equal
}
int CheckifInt(char* str){
    while(*str!='\0'){
        if(*str<'0' || *str>'9'){
            return 1;// Not an Integer
        }
        str++;
    }
    return 0;//An Integer
}

//Initializes all data from -f file and places them into a linked list, so they can be later added into the hashtable struct
global Initialize_Input(char* s) {//This function Initializes the assistant struct(in order to implement the
    FILE* fp = fopen(s, "r");//hash table and list later)and returns a pointer to it.
    if(fp==NULL){
        printf("ERROR while fopen");
            exit(1);
    }
    global A = (global)malloc(sizeof(globalhead));
    if(A==NULL){
        printf("Error malloc couldnt allocate memory");
        exit(1);
    }
    A->k = NULL;
    A->l=NULL;
    A->counthasvoted=0;
    A->count = 0;//A->count , counts the number of records inside the database
    
    katalogNode* current = NULL; //Initialize the current pointer

    while (1) {
        katalogNode* B = (katalogNode*)malloc(sizeof(katalogNode));
        if(B==NULL){
            printf("Error malloc couldnt allocate memory");
            exit(1);
        }
        B->fname = (char*)malloc(SIZE); //We have to dynamically allocate memory for the two strings
        B->lname = (char*)malloc(SIZE); //in order to access them.
        if((B->fname)==NULL || (B->lname)==NULL){
            printf("Error malloc couldnt allocate memory");
            exit(1);
        }
        if (fscanf(fp, "%d %s %s %d", &B->Pin, B->fname, B->lname, &B->TK) != 4) {
            free(B->fname);
            free(B->lname);
            free(B);
            break;  //fscanf returns the number of fields that were successfully converted and assigned,
                    //so in the other 2 cases, 0 and EOF we break from the loop and free the allocated memory.
        }
        B->vote= No;
        B->next = NULL;

        if (A->k == NULL) {
            A->k = B;
            current = B; // Set current to the first node
        } else {
            current->next = B; // Connect the new node to the previous node
            current = B; // Update current to the new node
        }

        A->count++;
    }

    fclose(fp);
    return A;
}
int EmptyList(katalogNode * p){//Checks if the list(the "list" here is the katalog struct) is empty
    return p==NULL;            //if p==NULL EmptyList() returns true==1
}

//Functions that insure the functionality, proper insert of data in the linear hashtable struct
void Initialize_Hashtable(int numberofrecordsinbuckets, global head){
    head->hs=(bucket**)malloc(m*sizeof(bucket*));//starting with 2 buckets at start
    if(head->hs==NULL){
        printf("Error, malloc couldnt allocate memory in the Initialize_Hashtable function");
        exit(1);
    }
    for(int j=0;j<m;j++){
        (head->hs)[j]=NULL;
    }
    int numberofbucketsatstart=m;
    head->numberofbuckets=m;
    head->i=0;
    head->splitbucket=0;// spltibucket look at the hs[0] that has a key with value 0
    //Our Hash function will be Hi(k)= k MOD 2^(i) * m , m= starting amount of buckets
    //if Hi(k)<p then rehash with H(i+1)(k)
    //if lambda > 0.75 then split the bucket , reallloc with m+1 total buckets and rehash with H(i+1)(k);
    //if head->numberofbuckets== 2* numberofbucketsatstart then numberofbucketsatstart=head->humberofbuckets
    //and p=0, i++
    //if were splitting a bucket and bucket with key p has OF buckets then delete them 
    //, and rehash them into the has table
    //for Hashtable search, with hi(k), i = head->i with its last value, else if hi(k)<p then rehash with h(i+1)(k)
    int key,countofrecords=0;
    katalogNode* current=head->k;
    while(current!=NULL){
        key=hashfunction(current->Pin,head->i);
        if(key< head->splitbucket){//if h(i)(k) < p
            key=hashfunction(current->Pin, (head->i)+1);
            AddtoHashTable(key,current,head->hs, numberofrecordsinbuckets);
            countofrecords++;
        }
        else{
            AddtoHashTable(key,current,head->hs, numberofrecordsinbuckets);
            countofrecords++;
        }
        head->lamda=(float) countofrecords /((float) (head->numberofbuckets) * (float)numberofrecordsinbuckets);
        if(head->lamda > 0.75){
            //bucketsplit == REALLOC by 1 bucket at a time
            head->numberofbuckets++;
            head->hs=(bucket **)realloc(head->hs, (head->numberofbuckets) *sizeof(bucket *));
            head->hs[head->numberofbuckets-1]=NULL;
            //rehash the values of p and OF buckets with h(i+1)(k)
            rehash(head,numberofrecordsinbuckets);
            head->splitbucket++;
        }
        if(head->numberofbuckets==2* numberofbucketsatstart){
            head->splitbucket=0;
            head->i++;
            numberofbucketsatstart=head->numberofbuckets;
        }
        current=current->next;
    }
    head->bucketsatstart=numberofbucketsatstart;
    return;
}
int hashfunction(int Pin, int i){
    int key=Pin % (int) (pow(2,i)*m);
    return key;
}
void rehash(global head, int b){
    int recordCount = 0;
    bucket* currentBucket = head->hs[head->splitbucket];
    //The below loop is done to know exactly how many Records we need to allocate dynamically the exact memory for them later
    //This way we dont waste any extra bytes.
    while(currentBucket!=NULL){
        Record* currentRecord=currentBucket->Rp;
        while(currentRecord!=NULL){
            recordCount++;
            currentRecord=currentRecord->next;
        }
        currentBucket=currentBucket->next;
    }
    // Store the records of the split bucket temporarily before rehashing.
    Record** tempRecords = (Record**)malloc(recordCount * sizeof(Record*));//head->numberofbuckets, 
    //sthn akraia periptvsh pou ola ta stoixeia einai sto idio bucket
    if (tempRecords==NULL){
        printf("Memory allocation failed in rehash.\n");
        exit(1);
    }
    recordCount=0;
    currentBucket=head->hs[head->splitbucket];    
    // Extract records from the current bucket and any overflow buckets.
    while (currentBucket!=NULL){
        Record* currentRecord=currentBucket->Rp;
        while (currentRecord!=NULL){
            tempRecords[recordCount]=currentRecord;
            currentRecord=currentRecord->next;
            recordCount++;
        }
        bucket* oldBucket=currentBucket;
        currentBucket = currentBucket->next;
        free(oldBucket);//Free the bucket structure, but keep the records for rehashing.
    }
    // Empty the split bucket
    head->hs[head->splitbucket] = NULL;
    // Reinsert the records using the new hash function
    for (int i = 0; i < recordCount; i++){
        int key = hashfunction(tempRecords[i]->Pin, head->i + 1);
        AddtoHashTable(key, tempRecords[i]->k, head->hs, b);
        free(tempRecords[i]);//Record is now rehashed, so we can free the old one.
    }
    free(tempRecords);
}
//the below functions insert a record to the correct bucket
void AddtoHashTable(int key, katalogNode* current, bucket** bucketpointer, int b) {
    if (bucketpointer[key] == NULL) {
        // If no element has been inserted yet to this part of the hash table
        Record* newRecord = createNewRecord(current);
        bucketpointer[key] = createNewBucket(newRecord);
        return;
    }
    bucket* currentBucket = bucketpointer[key];
    while (currentBucket) {
        if (currentBucket->elementsInbucket < b) {
            // Find last record in the bucket and add the new record there
            Record* currentRecord = currentBucket->Rp;
            while (currentRecord->next) {
                currentRecord = currentRecord->next;
            }
            currentRecord->next = createNewRecord(current);
            currentBucket->elementsInbucket++;
            return;
        } else if (!currentBucket->next) {
            // If the current bucket is full and there's no overflow bucket, add an overflow bucket
            Record* newRecord = createNewRecord(current);
            currentBucket->next = createNewBucket(newRecord);
            return;
        }
        currentBucket = currentBucket->next;
    }
}
Record* createNewRecord(katalogNode* current) {
    Record* newRecord = (Record*)malloc(sizeof(Record));
    if (newRecord == NULL) {
        printf("Error, couldn't allocate memory with malloc in createNewRecord function");
        exit(1);
    }
    newRecord->Pin = current->Pin;
    newRecord->k = current;
    newRecord->next = NULL;
    return newRecord;
}
bucket* createNewBucket(Record* record) {
    bucket* newBucket = (bucket*)malloc(sizeof(bucket));
    if (newBucket == NULL) {
        printf("Trouble allocating memory with malloc in createNewBucket function\n");
        exit(1);
    }
    newBucket->elementsInbucket = 1;
    newBucket->Rp = record;
    newBucket->next = NULL;
    return newBucket;
}

//The function that adds voters into the "voted" category
int AddtoList(int x, global p){
    katalogNode* B=SearchInhash(x,p);
    if (B==NULL){
        printf("%d does not exist\n", x);
        return -1;
    }
    if(B->vote==Yes){
        printf("Malformed input, this voter with Pin %d has already voted\n", B->Pin);
        return -1;
    }
    p->counthasvoted++;
    if (p->l==NULL){
        invertedNode* A=(invertedNode*)malloc(sizeof(invertedNode));
        if(A==NULL){
            printf("Error malloc couldnt allocate memory");
            exit(1);
        }
        A->number=1;
        A->next=NULL;
        p->l=A;
        listNode* B=(listNode*)malloc(sizeof(listNode));
        if(B==NULL){
            printf("Error malloc couldnt allocate memory");
            exit(1);
        }
        B->data=SearchInhash(x,p);
        B->next=NULL;
        B->Pin=x;
        (p->l)->N=B;
        (B->data)->vote= Yes;
        (p->l)->TK=(B->data)->TK;
        return 0;//everything went ok
    }
    //we first need to check if the Pin were trying to insert already has a TK
    //and if it is already in the struct
    invertedNode* current=p->l;
    B->vote=Yes;
    while(current!=NULL){
        if((current->TK)==(B->TK)){//if we find it then just immidietly add it on that TK
            listNode* C=(listNode*)malloc(sizeof(listNode));
            if(C==NULL){
                printf("Error malloc couldnt allocate memory");
                exit(1);
            }
            //then will just add the new node on the start of the N list
            current->number++;
            C->data=B;
            C->Pin=x;
            C->next=current->N;
            current->N=C;
            ((C->data)->vote)=Yes;
            return 0;
        }
        else if(current->next==NULL){
            invertedNode* A=(invertedNode*)malloc(sizeof(invertedNode));
            if(A==NULL){
                printf("Error malloc couldnt allocate memory");
                exit(1);
            }
            A->TK=B->TK;
            A->number=1;
            A->next=NULL;
            listNode* Z=(listNode*)malloc(sizeof(listNode));
            if(Z==NULL){
                printf("Error malloc couldnt allocate memory");
                exit(1);
            }
            Z->Pin=x;
            Z->data=B;
            Z->next=NULL;
            A->N=Z;
            current->next=A;
            (Z->data)->vote=Yes;
            return 0;
        }
        current=current->next;
    }
    return 0;
}
katalogNode* SearchInhash(int x, global head){
    int key=hashfunction(x,head->i);
    if(key< head->splitbucket){//if h(k) < p then rehash with search with h(i+1)(k)
        key=hashfunction(x, head->i +1);
        bucket* temp=head->hs[key];
        Record* currentrecord;
        while(temp!=NULL){
            currentrecord=temp->Rp;
            while(currentrecord!=NULL){
                if(currentrecord->Pin==x){
                    return currentrecord->k;
                }
                currentrecord=currentrecord->next;
            }
            temp=temp->next;
        }
    }
    else{
        bucket* temp=head->hs[key];
        Record* currentrecord;
        while(temp!=NULL){
            currentrecord=temp->Rp;
            while(currentrecord!=NULL){
                if(currentrecord->Pin==x){
                    return currentrecord->k;
                }
                currentrecord=currentrecord->next;
            }
            temp=temp->next;
        }
    }
    return NULL;
}

//Different Print functions that helped debugging, implementing and organizing the mvote application program
void PrintLIst(katalogNode* p){ //simple function to print all the records in a katalog form
    if(EmptyList(p)){
        return;
    }
    katalogNode* current=p;
    while(current!=NULL){
        printf("%d %s %s %d ", current->Pin, current->fname, current->lname, current->TK);
        if(current->vote==No){//just double checking that all records are initialized with voted==No
            printf("No \n");
        }
        else{
            printf("Yes\n");
        }
        current=current->next;
    }
    return;
}
void PrintinvertedList(global p){
    if((p->l)==NULL){
        printf("Noone has voted yet");
        return;
    }
    invertedNode* current=(p->l);
    while(current!=NULL){
        printf("%d | has %d voters ",current->TK,current->number);
        listNode* temp=current->N;
        while(temp!=NULL){
            printf("%d ", temp->Pin);
            temp=temp->next;
        }
        printf("\n");
        current=current->next;
    }
    return;
}
void PrintPromt(void){
    printf("1. l <pin>\n"
        "2. i <pin> <lname> <fname> <zip>\n"
        "3. m <pin>\n"
        "4. bv <fileofkeys>\n"
        "5. v\n"
        "6. perc\n"
        "7. z <zipcode>\n"
        "8. o\n"
        "9. exit:\n"
    );
    printf("Please type correctly the operation you want to run\n");
    return;
}
void printHashTable(global head) {
    if (!head || !head->hs) {
        printf("Hash table not initialized.\n");
        return;
    }
    for (int i = 0; i < head->numberofbuckets; i++) {
        printf("Bucket %d:\n", i);

        bucket* currentBucket = head->hs[i];
        while (currentBucket) {
            Record* currentRecord = currentBucket->Rp;
            while (currentRecord) {
                printf("  Pin: %d, First Name: %s, Last Name: %s, TK: %d, Voted: %s\n",
                       currentRecord->Pin,
                       currentRecord->k->fname,
                       currentRecord->k->lname,
                       currentRecord->k->TK,
                       currentRecord->k->vote ? "Yes" : "No");

                currentRecord = currentRecord->next;
            }
            currentBucket = currentBucket->next;
            if(currentBucket) {
                printf("  -- Overflow bucket --\n");
            }
        }
        printf("\n");
    }
}

//the functions for implementing the MergeSort alogirthm for the list struct
invertedNode* MergeSortList(invertedNode* head){
    //Here we test the base case, (1) if the list is empty or (2) if the list only has one node, so no point in sorting
    if((head==NULL) || (head->next==NULL)){
        return head;
    }
    invertedNode* mid = getmiddle(head);
    invertedNode* half = mid->next;
    mid->next = NULL;
    head=MergeSortList(head);
    half=MergeSortList(half);
    head=merge(head,half);
    return head;
}
invertedNode* merge(invertedNode* left, invertedNode* right){
    if(left==NULL){
        return right;
    }
    if(right==NULL){
        return left;
    }
    if(left->number > right->number){
        left->next = merge(left->next, right);
        return left;
    }
    else{
        right->next = merge(left, right->next);
        return right;
    }
}
invertedNode* getmiddle(invertedNode* head){
    if(head==NULL){
        return head;
    }
    invertedNode* slow = head;
    invertedNode* fast = head->next;
    while(fast && fast->next){
        slow = slow->next;
        fast = fast->next->next;
    }
    return slow;
}
global MergeSort(global p){
    p->l = MergeSortList(p->l);
    return p;
}

//the functions for freeying the structs
int freeHashtable(global head){
    int NoOfBytes=0;
    bucket* currentBucket;
    for(int i=0; i< (head->numberofbuckets); i++){
        currentBucket=head->hs[i];
        while(currentBucket!=NULL){
            bucket* nextBucket = currentBucket->next;
            Record* currentRecord = currentBucket->Rp;
            while (currentRecord) {
                Record* nextRecord = currentRecord->next;
                NoOfBytes += sizeof(currentRecord);
                free(currentRecord);
                currentRecord = nextRecord;
            }
            NoOfBytes += sizeof(currentBucket);
            free(currentBucket);
            currentBucket = nextBucket;
        }   
    }
    NoOfBytes += sizeof(head->hs);
    free(head->hs);
    return NoOfBytes;
}
int freekatalog(global head){
    int NoOfBytes=0;
    katalogNode* current=head->k;
    while(head->k!=NULL){
        current=head->k;
        head->k=head->k->next;
        NoOfBytes += sizeof(current->fname);
        NoOfBytes += sizeof(current->lname);
        NoOfBytes += sizeof(katalogNode);
        free(current->fname);
        free(current->lname);
        free(current);
    }
    NoOfBytes += sizeof(head->k);
    free(head->k);
    return NoOfBytes;
}
int freeList(global head){
    int NoOfBytes=0;
    invertedNode* current=(head->l);
    while(head->l!=NULL){
        current=head->l;
        head->l=head->l->next;
        listNode* temp=current->N;
        while(current->N!=NULL){
            temp=current->N;
            current->N=current->N->next;
            NoOfBytes += sizeof(listNode);
            free(temp);
        }
        NoOfBytes += sizeof(invertedNode);
        free(current);
    }
    NoOfBytes += sizeof(head->l);
    free(head->l);
    return NoOfBytes;
}
